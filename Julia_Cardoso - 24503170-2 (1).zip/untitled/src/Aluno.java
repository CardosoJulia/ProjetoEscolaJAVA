public class Aluno {
    private String nome;
    private String matricula;
    private Double nota;

    public void ExibirDados(){
        System.out.printf("nome:%s",nome,"Matricula:%s",matricula,"Nota:%f",nota);
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        this.nota = nota;
    }
}

public class AlunoPosGraduação extends Aluno {

    String Orientador;

    @Override
    public void ExibirDados() {
        super.ExibirDados();
        System.out.printf("Orientador %s",Orientador);
    }
}

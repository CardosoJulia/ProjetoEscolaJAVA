public class AlunoGraduacao extends Aluno{
    String trabalhoConclusao;

    @Override
    public void ExibirDados() {
        super.ExibirDados();
        System.out.printf("TCC:%s",trabalhoConclusao);
    }
}
